package spctrum.report.vo;

public class ReportVO {
	
	
	private String boardreportNumber;
	private String anonymousboardPostnum;
	private String mbtiboardPostnum;
	private String boardreportDate;
	private String boardClassificationCode;
	private String memberId;
	private String boardreportReason;
	private String memberReportNum;
	private String memberReportedId;
	private String memberReportId;
	private String memberReportDate;
	private String memberReportReason;
	
	public String getBoardreportNumber() {
		return boardreportNumber;
	}
	public void setBoardreportNumber(String boardreportNumber) {
		this.boardreportNumber = boardreportNumber;
	}
	public String getAnonymousboardPostnum() {
		return anonymousboardPostnum;
	}
	public void setAnonymousboardPostnum(String anonymousboardPostnum) {
		this.anonymousboardPostnum = anonymousboardPostnum;
	}
	public String getMbtiboardPostnum() {
		return mbtiboardPostnum;
	}
	public void setMbtiboardPostnum(String mbtiboardPostnum) {
		this.mbtiboardPostnum = mbtiboardPostnum;
	}
	public String getBoardreportDate() {
		return boardreportDate;
	}
	public void setBoardreportDate(String boardreportDate) {
		this.boardreportDate = boardreportDate;
	}
	public String getBoardClassificationCode() {
		return boardClassificationCode;
	}
	public void setBoardClassificationCode(String boardClassificationCode) {
		this.boardClassificationCode = boardClassificationCode;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getBoardreportReason() {
		return boardreportReason;
	}
	public void setBoardreportReason(String boardreportReason) {
		this.boardreportReason = boardreportReason;
	}
	public String getMemberReportNum() {
		return memberReportNum;
	}
	public void setMemberReportNum(String memberReportNum) {
		this.memberReportNum = memberReportNum;
	}
	public String getMemberReportedId() {
		return memberReportedId;
	}
	public void setMemberReportedId(String memberReportedId) {
		this.memberReportedId = memberReportedId;
	}
	public String getMemberReportId() {
		return memberReportId;
	}
	public void setMemberReportId(String memberReportId) {
		this.memberReportId = memberReportId;
	}
	public String getMemberReportDate() {
		return memberReportDate;
	}
	public void setMemberReportDate(String memberReportDate) {
		this.memberReportDate = memberReportDate;
	}
	public String getMemberReportReason() {
		return memberReportReason;
	}
	public void setMemberReportReason(String memberReportReason) {
		this.memberReportReason = memberReportReason;
	}
	
	
	
	
	
}
