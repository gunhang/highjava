package spectrum.blacklist.vo;

public class BlacklistVO {
	
	
	private String blacklistNumber;
	private String memberId;
	private String blacklistReason;
	private String blacklistRgstrdate;
	private String blacklistBlackyn;
	private String blacklistReleasedate;
	private String reportcount;
	private String blacklistCheck;
	
	
	public String getBlacklistCheck() {
		return blacklistCheck;
	}
	public void setBlacklistCheck(String blacklistCheck) {
		this.blacklistCheck = blacklistCheck;
	}
	public String getReportcount() {
		return reportcount;
	}
	public void setReportcount(String reportcount) {
		this.reportcount = reportcount;
	}
	public String getBlacklistNumber() {
		return blacklistNumber;
	}
	public void setBlacklistNumber(String blacklistNumber) {
		this.blacklistNumber = blacklistNumber;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getBlacklistReason() {
		return blacklistReason;
	}
	public void setBlacklistReason(String blacklistReason) {
		this.blacklistReason = blacklistReason;
	}
	public String getBlacklistRgstrdate() {
		return blacklistRgstrdate;
	}
	public void setBlacklistRgstrdate(String blacklistRgstrdate) {
		this.blacklistRgstrdate = blacklistRgstrdate;
	}
	public String getBlacklistBlackyn() {
		return blacklistBlackyn;
	}
	public void setBlacklistBlackyn(String blacklistBlackyn) {
		this.blacklistBlackyn = blacklistBlackyn;
	}
	public String getBlacklistReleasedate() {
		return blacklistReleasedate;
	}
	public void setBlacklistReleasedate(String blacklistReleasedate) {
		this.blacklistReleasedate = blacklistReleasedate;
	}
	
	
	
}
